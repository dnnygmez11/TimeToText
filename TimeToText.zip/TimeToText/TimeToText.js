//---------------------------------
// Title:  Time to Text
// Author: Danny Gomez Chaves
// Date:   27 Jul 2021
//---------------------------------

/*Variables que pertenecen a elementos de HTML*/
var tiempoNum = document.getElementById('tiempoNum');
var tiempoText = document.getElementById('tiempoText');
var refrescarBtn = document.getElementById('refrescarBtn');

/*Variables de tipo Date*/
var date;
let time;
date = new Date(); //variable que me permite obtener la hora actual

tiempoText.innerHTML = timeToText(date); //asignacion del tiempo actual a un elemento de HTML
/*Funcion que refresca la pagina cuando es presionado el boton que le corresponde*/
function getTime(){   
    
   location.reload(); 
}
/*Funcion que convierte el tiempo tipo Date a Texto*/
function timeToText(dateT) { //recibe el tiempo del sistema
    let horaActual = dateT.getHours(); //obtiene la hora del sistema
    let minutoActual = dateT.getMinutes(); //obtiene el minuto del sistema

    var minutosEnTexto = minuto(minutoActual); //llama al metodo minuto() - traduce los minutos a texto.
    var horaEnTexto = hora(horaActual); //llama al metodo hora() - traduce las horas a texto.
    var momentoEnTexto = momentoDelDia(horaActual); //llama a momentoDelDia() - retorna el momento del dia de la hora establecida

    let resultado; //variable para alojar el resultado

    switch (true) { //verifica si es medio dia o media noche antes de continuar
        case (horaActual == 00 && minutoActual == 00): resultado = "Es media noche."; break;
        case (horaActual == 12 && minutoActual == 00): resultado = "Es medio dia."; break;
        default: resultado = horaEnTexto + minutosEnTexto + momentoEnTexto; //concatena la hora, minutos y momento del dia
    }
    return resultado;
}
/*Funcion que convierte el numero que corresponde a hora en texto*/
function hora(horaDate) { //recibe la hora del sistema
    let horaTemp; //variable para almacernar el resultado
    switch (horaDate) { //asigna un string dependiendo del numero que reciba

        case 1:
        case 13: horaTemp = "Es la una "; break;
        case 2:
        case 14: horaTemp = "Son las dos "; break;
        case 3:
        case 15: horaTemp = "Son las tres "; break;
        case 4:
        case 16: horaTemp = "Son las cuatro "; break;
        case 5:
        case 17: horaTemp = "Son las cinco "; break;
        case 6:
        case 18: horaTemp = "Son las seis "; break;
        case 7:
        case 19: horaTemp = "Son las siete "; break;
        case 8:
        case 20: horaTemp = "Son las ocho "; break;
        case 9:
        case 21: horaTemp = "Son las nueve "; break;
        case 10:
        case 22: horaTemp = "Son las diez "; break;
        case 11:
        case 23: horaTemp = "Son las once "; break;
        case 12:
        case 00: horaTemp = "Son las doce "; break;
        default: console.log("Something wrong happened in hora()!");
    }
    return horaTemp;
}
/*Funcion que devuelve 'en punto' , 'y cuarto', 'y media' si los minutos cumplen con la condicion.
De no ser asi, llama una funcion que retorna el texto que corresponde al minuto recibido*/
function minuto(minutoDate) { //recibe el minuto del sistema
    let minutoTemp; //variable para almacernar el resultado
    switch (minutoDate) {
        case 00: minutoTemp = "en punto"; break;
        case 15: minutoTemp = "y cuarto"; break;
        case 30: minutoTemp = "y media"; break;
        default: minutoTemp = minutesText(minutoDate); //llama a la funcion que retorna el nombre del minuto que no cumple con las condiciones anteriores
    }
    return minutoTemp;
}
/*Funcion que determina el momento del dia de la hora correspondiente*/
function momentoDelDia(horaDate) { //recibe la hora del sistema
    let momentoTemp; //variable para almacernar el resultado
    switch (true) {
        case horaDate > 18: momentoTemp = " de la noche."; break;  // despues de las 16 horas
        case horaDate >= 12: momentoTemp = " de la tarde."; break; // despues o igual a las 12 horas
        case horaDate < 12: momentoTemp = " de la mañana."; break; // antes de las 12 horas
        default: console.log("Something wrong happened in momentoDeDia()!");
    }
    return momentoTemp;
}

/*Funcion que determina el nombre del minuto que recibe por parametros.
Se decide utilizar un Objeto e Iterarlo ya que un Switch puede resultar menos eficiente al tratarse de varios casos.*/

function minutesText(numeroMinuto) { //recibe la el minuto del sistema
    //se crea un objeto numeros para almacenar e indexar los datos
    var numeros = {
        01: "y uno",
        02: "y dos",
        03: "y tres",
        04: "y cuatro",
        05: "y cinco",
        06: "y seis",
        07: "y siete",
        08: "y ocho",
        09: "y nueve",
        10: "y diez",
        11: "y once ",
        12: "y doce",
        13: "y trece",
        14: "y catorce",
        16: "y dieciseis",
        17: "y diecisiete",
        18: "y dieciocho",
        19: "y diecinueve",
        20: "y veinte",
        21: "y veintiuno",
        22: "y veintidos",
        23: "y veintitres",
        24: "y veinticuatro",
        25: "y veinticinco",
        26: "y veintiseis",
        27: "y veintisiete",
        28: "y veintiocho",
        29: "y veintinueve",
        30: "y treinta",
        31: "y treinta y uno",
        32: "y treinta y dos",
        33: "y treinta y tres",
        34: "y treinta y cuatro",
        35: "y treinta y cinco",
        36: "y treinta y seis",
        37: "y treinta y siete",
        38: "y treinta y ocho",
        39: "y treinta y nueve",
        40: "y cuarenta",
        41: "y cuarentay uno ",
        42: "y cuarenta y dos",
        43: "y cuarenta y tres",
        44: "y cuarenta y cuatro",
        45: "y cuarenta y cinco",
        46: "y cuarenta y seis",
        47: "y cuarenta y siete",
        48: "y cuarenta y ocho",
        49: "y cuarenta y nueve",
        50: "y cincuenta",
        51: "y cincuenta y uno",
        52: "y cincuenta y dos",
        53: "y cincuenta y tres",
        54: "y cincuenta y cuatro",
        55: "y cincuenta y cinco",
        56: "y cincuenta y seis",
        57: "y cincuenta y siete",
        58: "y cincuenta y ocho",
        59: "y cincuenta y nueve"

    };
    return numeros[numeroMinuto]; //retorna el numero con el indice que corresponde al minuto que recibe por parametros
}
 
/* 
function startTime() {
    const today = new Date();
    let h = today.getHours();
    let m = today.getMinutes();
    let s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    tiempoNum.innerHTML =  h + ":" + m + ":" + s;
    setTimeout(startTime, 1000);
  }
  
  function checkTime(i) {
    if (i < 10) {i = "0" + i};   
    return i;
  }
 
//startTime();
 
*/ 

/*HORAS PREDETERMINADAS*/
/*Funciones que permiten probar la funcionalidad del ejercicio en distintas horas
y con casos especiales, tales como Medio Dia, Media Noche, en punto, y cuarto, y media.*/

/*Establece la hora a 9:00 am*/
function setEnPuntoBtn(){ 
    let dateTemp = new Date();
    dateTemp.setHours(9);
    dateTemp.setMinutes(00);
    tiempoNum.innerHTML = dateTemp.toLocaleTimeString();
    tiempoText.innerHTML = timeToText(dateTemp); 
}
/*Establece la hora a 11:15 pm*/
function setNocheBtn(){ 
    let dateTemp = new Date();
    dateTemp.setHours(23);
    dateTemp.setMinutes(15);
    tiempoNum.innerHTML = dateTemp.toLocaleTimeString();
    tiempoText.innerHTML = timeToText(dateTemp); 
}
/*Establece la hora a 10:30 am*/
function setMananaBtn(){ 
    let dateTemp = new Date();
    dateTemp.setHours(10);
    dateTemp.setMinutes(30);
    tiempoNum.innerHTML = dateTemp.toLocaleTimeString();
    tiempoText.innerHTML = timeToText(dateTemp); 
}
/*Establece la hora a 4:47 pm*/
function setTardeBtn(){ 
    let dateTemp = new Date();
    dateTemp.setHours(16);
    dateTemp.setMinutes(47);
    tiempoNum.innerHTML = dateTemp.toLocaleTimeString();
    tiempoText.innerHTML = timeToText(dateTemp); 
}
/*Establece la hora a 12:00 pm - Medio Dia*/
function setMedioDia(){ 
    let dateTemp = new Date();
    dateTemp.setHours(12);
    dateTemp.setMinutes(00);
    tiempoNum.innerHTML = dateTemp.toLocaleTimeString();
    tiempoText.innerHTML = timeToText(dateTemp); 
}
/*Establece la hora a 12:00 am - Media Noche*/
function setMediaNoche(){ 
    let dateTemp = new Date();
    dateTemp.setHours(00);
    dateTemp.setMinutes(00);
    tiempoNum.innerHTML = dateTemp.toLocaleTimeString();
    tiempoText.innerHTML = timeToText(dateTemp); 
}



/*Impresiones en consola para Testeo*/
time = date.getHours() + ":" + date.getMinutes();
console.log(date.toString());
console.log(time.toString());
console.log(date.toLocaleTimeString());
console.log(date.toLocaleTimeString());
console.log(date.getHours());
tiempoNum.innerHTML = date.toLocaleTimeString(); 
console.log(date.getHours());
console.log(date.toLocaleTimeString());
console.log(timeToText(date));